# AI Token Monitor 🚀

Track token usage and cost for OpenRouter, Groq, and OpenAI — with FastAPI integration.

## Features
- ✅ Token tracking per request and per chat session
- ✅ Cost estimation (real model pricing)
- ✅ Multi-turn chat session management
- ✅ FastAPI integration with middleware
- ✅ Production logging

## Install

```bash
pip install ai-token-monitor
```

## Quick Start

```python
from ai_token_monitor import TokenMonitor, ChatManager
from ai_token_monitor.utils import normalize_response, extract_reply

monitor = TokenMonitor()
chat_manager = ChatManager()

chat_id = chat_manager.create_chat("user_123")
chat_manager.add_message(chat_id, "user", "Hello!")

# After getting response from OpenAI/OpenRouter:
data = normalize_response(raw_response)
answer = extract_reply(data)
monitor.track(data, model="openai/gpt-4o-mini", chat_manager=chat_manager, chat_id=chat_id)

print(monitor.summary())
```

## Environment Variables

Copy `.env.example` to `.env` and set:

```
OPENROUTER_API_KEY=your_key_here
```

## Run the FastAPI Example

```bash
uvicorn examples.fastapi_app:app --reload
```

## Supported Models

- `openai/gpt-4o`, `openai/gpt-4o-mini`, `openai/gpt-3.5-turbo`
- `groq/llama3-8b-8192`, `groq/llama3-70b-8192`
- `mistralai/mixtral-8x7b-instruct`, `mistralai/mistral-7b-instruct`
- `anthropic/claude-3-haiku`, `anthropic/claude-3.5-sonnet`

## License

MIT
